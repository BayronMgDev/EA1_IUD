
package controller;

import dao.TipoIdentificacionDao;
import model.TipoIdentificacion;

import javax.swing.*;
import java.util.List;

public class TipoIdentificacionController {
    
    private TipoIdentificacionDao tipoIdentificacionDao;

    public TipoIdentificacionController(TipoIdentificacionDao tipoIdentificacionDao) {
        this.tipoIdentificacionDao = tipoIdentificacionDao;
    }
    
    public DefaultComboBoxModel llenarSelector(){
        DefaultComboBoxModel selectorTipoID = new DefaultComboBoxModel();
        List<TipoIdentificacion> tiposID = tipoIdentificacionDao.findAll();
        for(TipoIdentificacion elem: tiposID){
            selectorTipoID.addElement(elem.getNombre());
        }
        return selectorTipoID;
    }
}
