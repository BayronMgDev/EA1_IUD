
package dao;

import model.EstadoCivil;

import java.util.List;

public interface EstadoCivilDao {
    
    List<EstadoCivil> findAll();
}
